clang++ -Wall -Wextra -Werror *.cpp && ./a.out
rm a.out
